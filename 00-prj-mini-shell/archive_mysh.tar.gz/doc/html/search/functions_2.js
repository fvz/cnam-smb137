var searchData=
[
  ['freeif',['freeif',['../facilities_8h.html#a772362af303e2bda44e879b2af912c1a',1,'freeif(void *to_free):&#160;facilities.c'],['../facilities_8c.html#a772362af303e2bda44e879b2af912c1a',1,'freeif(void *to_free):&#160;facilities.c']]]
];
