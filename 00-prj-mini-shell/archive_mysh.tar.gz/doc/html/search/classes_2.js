var searchData=
[
  ['mysh_5fcontext_5fs',['mysh_context_s',['../structmysh__context__s.html',1,'']]],
  ['mysh_5fhistory_5fs',['mysh_history_s',['../structmysh__history__s.html',1,'']]]
];
