var searchData=
[
  ['mysh_20_2d_20shell_20linux_20minimal',['MySH - Shell Linux minimal',['../md_README.html',1,'']]]
];
