var searchData=
[
  ['vmyprintf_5fstream',['vmyprintf_stream',['../myprintf_8h.html#a5c3a004b65f55046a508c7f20f3deed2',1,'vmyprintf_stream(FILE *stream, int threshold, int level, const char *format, va_list args):&#160;myprintf.c'],['../myprintf_8c.html#a5c3a004b65f55046a508c7f20f3deed2',1,'vmyprintf_stream(FILE *stream, int threshold, int level, const char *format, va_list args):&#160;myprintf.c']]]
];
